/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ashfaq
 */
public class StudentProjectNew {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Student11 s1= new Student11("BSE","X","FA18");
      //  System.out.println("value is: "+ s1.program);
        System.out.println("Your name is: "+ s1.getName());
        s1.setName("Ahmed");
        System.out.println("My new name is : "+ s1.getName());
     //   System.out.println("New value is : "+ s1.program);
        Integer i=new Integer(4); //int i=4
        
//        System.out.println("Name is : "  + s1.name);
//        String s="BSE";
//        s1.name="XYZ";
//        s1.semester=0;
//        s1.program=s;
//        s1.takeClasses(s);
//        Student11 s2= new Student11();
//        System.out.println("Program of Second object is : "+ s2.program);
//        
    }
    
}
